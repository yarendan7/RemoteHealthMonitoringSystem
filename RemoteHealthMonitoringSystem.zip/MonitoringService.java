public class MonitoringService {
    public Alert processNewVitals(Patient p, VitalSignRecord v) {
        return null;
    }
}